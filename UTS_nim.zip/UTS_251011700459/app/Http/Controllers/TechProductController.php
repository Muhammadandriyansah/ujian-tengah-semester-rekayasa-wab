<?php

namespace App\Http\Controllers;

use App\Models\TechProduct;

class TechProductController extends Controller
{
    public function index()
    {
        $products = TechProduct::orderBy('release_date', 'desc')->get();

        return view('products.index', compact('products'));
    }

    public function show(string $id)
    {
        $product = TechProduct::findOrFail($id);

        return view('products.show', compact('product'));
    }
}
