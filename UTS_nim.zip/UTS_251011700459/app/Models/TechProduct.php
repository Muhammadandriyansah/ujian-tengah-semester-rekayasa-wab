<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TechProduct extends Model
{
    protected $fillable = [
        'name',
        'brand',
        'release_date',
        'specs',
        'price',
        'image',
        'description',
    ];

    protected $casts = [
        'release_date' => 'date',
        'price' => 'decimal:2',
    ];
}
