
@extends('layouts.app')

@section('title', 'Kontak')

@section('content')
<section class="py-5 bg-light">
    <div class="container py-4">
        <h1 class="fw-bold">Kontak Kami</h1>
        <p class="text-secondary">
            Hubungi PT Rretzelindo Sukses Pratama untuk informasi
            lebih lanjut.
        </p>
    </div>
</section>

<section class="py-5">
    <div class="container">
        <div class="row g-4">
            <div class="col-md-6">
                <h3>Informasi Kontak</h3>
                <p>
                    <strong>Perusahaan:</strong><br>
                    PT Rretzelindo Sukses Pratama
                </p>
                <p>
                    <strong>Email:</strong><br>
                    Silakan tambahkan email resmi perusahaan.
                </p>
                <p>
                    <strong>Alamat:</strong><br>
                    Silakan tambahkan alamat resmi perusahaan.
                </p>
            </div>

            <div class="col-md-6">
                <div class="card shadow-sm p-4">
                    <h4>Jam Layanan</h4>
                    <p>
                        Silakan sesuaikan jam operasional dengan
                        informasi resmi perusahaan.
                    </p>
                    <a href="{{ route('layanan') }}"
                        class="btn btn-primary">
                        Lihat Layanan
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>
@endsection
