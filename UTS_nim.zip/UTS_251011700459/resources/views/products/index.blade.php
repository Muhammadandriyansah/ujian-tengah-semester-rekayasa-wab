
@extends('layouts.app')

@section('title', 'Beranda')

@section('content')

<!-- BERANDA -->
<section class="hero" id="beranda">
    <div class="container">
        <span class="badge bg-info text-dark mb-3">
            NEXT GENERATION TECHNOLOGY
        </span>

        <h1 class="display-4 fw-bold">
            Temukan Teknologi<br>
            untuk Masa Depan.
        </h1>

        <p class="lead mt-3 mb-4">
            Jelajahi koleksi smartphone, laptop, tablet,
            dan perangkat digital pilihan.
        </p>

        <a href="#katalog" class="btn btn-light btn-lg">
            Jelajahi Katalog
        </a>
    </div>
</section>

<!-- KATALOG PRODUK -->
<section class="section-space" id="katalog">
    <div class="container">
        <div class="d-flex justify-content-between align-items-center
                    flex-wrap gap-3 mb-4">
            <div>
                <h2 class="fw-bold">Katalog Teknologi</h2>
                <p class="text-secondary mb-0">
                    Pilihan perangkat teknologi untuk kebutuhanmu.
                </p>
            </div>

            <span class="badge bg-primary fs-6">
                {{ $products->count() }} Produk
            </span>
        </div>

        <div class="row g-4">
            @forelse ($products as $product)
                <div class="col-sm-6 col-lg-4">
                    <div class="card product-card shadow-sm">
                        <img
                            src="{{ asset('assets/images/' . $product->image) }}"
                            class="product-image"
                            alt="{{ $product->name }}"
                            onerror="this.onerror=null;this.src='https://placehold.co/600x400/f1f5f9/334155?text=Produk';"
                        >

                        <div class="card-body d-flex flex-column">
                            <span class="badge bg-light text-primary
                                         align-self-start mb-2">
                                {{ $product->brand }}
                            </span>

                            <h5 class="fw-bold">
                                {{ $product->name }}
                            </h5>

                            <p class="text-secondary">
                                {{ \Illuminate\Support\Str::limit(
                                    $product->description, 100
                                ) }}
                            </p>

                            <p class="price mt-auto">
                                Rp {{ number_format(
                                    (float) $product->price, 0, ',', '.'
                                ) }}
                            </p>

                            <a href="{{ route('products.show', $product) }}"
                               class="btn btn-tech w-100">
                                Lihat Detail
                            </a>
                        </div>
                    </div>
                </div>
            @empty
                <div class="col-12">
                    <div class="alert alert-warning">
                        Belum ada produk. Silakan jalankan seeder.
                    </div>
                </div>
            @endforelse
        </div>
    </div>
</section>

<!-- TENTANG KAMI -->
<section class="section-space bg-white" id="tentang">
    <div class="container">
        <div class="row align-items-center g-4">
            <div class="col-lg-7">
                <span class="badge bg-primary mb-3">
                    TENTANG TECHNOVA
                </span>

                <h2 class="fw-bold">
                    Teknologi untuk Masa Depan
                </h2>

                <p class="text-secondary mt-3">
                    TechNova merupakan katalog teknologi digital
                    yang menyajikan informasi berbagai perangkat,
                    mulai dari smartphone, laptop, tablet,
                    hingga perangkat elektronik modern.
                </p>

                <p class="text-secondary">
                    Pengunjung dapat melihat deskripsi, spesifikasi,
                    harga, dan tanggal rilis produk melalui satu
                    website yang mudah digunakan.
                </p>

                <a href="#katalog" class="btn btn-tech">
                    Lihat Produk
                </a>
            </div>

            <div class="col-lg-5">
                <div class="p-5 rounded-4 text-center"
                     style="background:#eef4ff">
                    <h2 class="fw-bold text-primary">TechNova.</h2>
                    <p class="text-secondary mb-0">
                        Explore Technology.<br>
                        Discover Possibilities.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- KONTAK -->
<section class="section-space" id="kontak">
    <div class="container">
        <div class="text-center mb-5">
            <span class="badge bg-primary mb-2">HUBUNGI KAMI</span>
            <h2 class="fw-bold">Kontak TechNova</h2>
            <p class="text-secondary">
                Informasi mengenai katalog teknologi kami.
            </p>
        </div>

        <div class="row g-4 justify-content-center">
            <div class="col-md-4">
                <div class="card product-card shadow-sm p-4 text-center">
                    <h5 class="fw-bold">Informasi</h5>
                    <p class="text-secondary mb-0">
                        Katalog Teknologi Terbaru
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card product-card shadow-sm p-4 text-center">
                    <h5 class="fw-bold">Email</h5>
                    <p class="text-secondary mb-0">
                        technova@example.com
                    </p>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card product-card shadow-sm p-4 text-center">
                    <h5 class="fw-bold">Lokasi</h5>
                    <p class="text-secondary mb-0">
                        Tangerang Selatan, Indonesia
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>

@endsection
