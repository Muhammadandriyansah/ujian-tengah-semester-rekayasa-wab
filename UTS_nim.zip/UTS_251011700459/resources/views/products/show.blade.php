@extends('layouts.app')

@section('title', $product->name)

@section('content')

<section class="section-space">
    <div class="container">

        <a href="{{ route('products.index') }}"
           class="btn btn-outline-primary mb-4">
            &larr; Kembali ke Katalog
        </a>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="row g-0">

                <div class="col-lg-6 bg-white d-flex align-items-center">
                    <img
                        src="{{ asset('assets/images/' . $product->image) }}"
                        alt="{{ $product->name }}"
                        class="img-fluid w-100 p-4"
                        style="max-height: 480px; object-fit: contain;"
                        onerror="this.onerror=null;this.src='https://placehold.co/600x500/f1f5f9/334155?text=Gambar+Produk';"
                    >
                </div>

                <div class="col-lg-6">
                    <div class="p-4 p-lg-5">

                        <span class="badge bg-primary mb-3">
                            {{ $product->brand }}
                        </span>

                        <h1 class="fw-bold mb-3">
                            {{ $product->name }}
                        </h1>

                        <p class="price fs-3">
                            Rp {{ number_format(
                                (float) $product->price,
                                0, ',', '.'
                            ) }}
                        </p>

                        <hr>

                        <h5 class="fw-bold">Deskripsi Produk</h5>
                        <p class="text-secondary">
                            {{ $product->description }}
                        </p>

                        <h5 class="fw-bold mt-4">Spesifikasi</h5>
                        <p class="text-secondary">
                            {{ $product->specs }}
                        </p>

                        <div class="mt-4">
                            <strong>Tanggal Rilis:</strong>
                            {{ $product->release_date->format('d-m-Y') }}
                        </div>

                        <div class="mt-4">
                            <a href="{{ route('products.index') }}"
                               class="btn btn-tech">
                                Kembali ke Semua Produk
                            </a>
                        </div>

                    </div>
                </div>

            </div>
        </div>

    </div>
</section>

@endsection