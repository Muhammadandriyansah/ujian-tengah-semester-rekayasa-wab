<?php

namespace Database\Seeders;

use App\Models\TechProduct;
use Illuminate\Database\Seeder;

class TechProductSeeder extends Seeder
{
    public function run(): void
    {
        $products = [
            [
                'name' => 'ZenBook Pro 14',
                'brand' => 'ASUS',
                'release_date' => '2025-02-10',
                'specs' => 'Intel Core Ultra 7, RAM 16 GB, SSD 1 TB, layar OLED 14 inci',
                'price' => 21999000,
                'image' => 'laptop.jpg',
                'description' => 'Laptop produktivitas dengan layar OLED tajam untuk pekerjaan kreatif, kuliah, dan aktivitas sehari-hari.',
            ],
            [
                'name' => 'Galaxy S25',
                'brand' => 'Samsung',
                'release_date' => '2025-01-22',
                'specs' => 'Layar AMOLED, RAM 12 GB, penyimpanan 256 GB, kamera multi-lensa',
                'price' => 14999000,
                'image' => 'headphone.jpg',
                'description' => 'Smartphone untuk komunikasi, fotografi, hiburan, dan produktivitas mobile.',
            ],
            [
                'name' => 'iPad Air',
                'brand' => 'Apple',
                'release_date' => '2025-03-12',
                'specs' => 'Layar 11 inci, chip Apple seri M, dukungan stylus, Wi-Fi',
                'price' => 9999000,
                'image' => 'tablet.jpg',
                'description' => 'Tablet serbaguna untuk membaca materi kuliah, membuat catatan, dan menikmati konten digital.',
            ],
            [
                'name' => 'Watch Fit 4',
                'brand' => 'Huawei',
                'release_date' => '2025-05-15',
                'specs' => 'Layar AMOLED, pemantauan aktivitas, GPS, notifikasi ponsel',
                'price' => 1899000,
                'image' => 'smartwatch.jpg',
                'description' => 'Jam pintar untuk membantu memantau aktivitas harian dan menerima notifikasi.',
            ],
            [
                'name' => 'WH-1000XM6',
                'brand' => 'Sony',
                'release_date' => '2025-05-15',
                'specs' => 'Headphone nirkabel, peredam bising, mikrofon, konektivitas Bluetooth',
                'price' => 6999000,
                'image' => 'smartphone.jpg',
                'description' => 'Headphone untuk mendengarkan musik dan mengikuti rapat dengan pengalaman audio yang nyaman.',
            ],
            [
                'name' => 'EOS R50',
                'brand' => 'Canon',
                'release_date' => '2023-02-08',
                'specs' => 'Kamera mirrorless, sensor APS-C, video 4K, lensa dapat diganti',
                'price' => 10999000,
                'image' => 'camera.jpg',
                'description' => 'Kamera ringkas untuk belajar fotografi, membuat konten, dan merekam kegiatan.',
            ],
        ];

        foreach ($products as $product) {
            TechProduct::updateOrCreate(
                ['name' => $product['name']],
                $product
            );
        }
    }
}
