<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\TechProductController;

Route::get('/', [TechProductController::class, 'index'])
    ->name('products.index');

Route::get('/produk/{techProduct}', [TechProductController::class, 'show'])
    ->name('products.show');