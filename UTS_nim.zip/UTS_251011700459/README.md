# KOREKSI SOURCE UTS REKAYASA WEB — NIM AKHIR 9

Tema: Katalog Teknologi Terbaru  
Tabel: `tech_products`  
Fitur: daftar produk dan detail produk. Tidak ada fitur CRUD.

## Penting
ZIP ini berisi **file kode tugas**, bukan kerangka proyek Laravel lengkap. Itu sebabnya `php artisan` tidak bisa berjalan bila folder tujuan belum memiliki file `artisan`. Jangan hanya menaruh file ZIP ini di folder kosong dan langsung menjalankan perintah artisan.

## 1. Buat kerangka Laravel lengkap
Buka terminal di folder induk proyek, lalu jalankan:

```powershell
composer create-project laravel/laravel UTS_NIM
```

Jika folder `UTS_NIM` sudah ada, gunakan nama folder baru seperti `UTS_NIM_LARAVEL` agar file yang ada tidak tertimpa.

## 2. Salin file kode tugas
Ekstrak ZIP ini. Salin isi folder `app`, `database`, `resources`, dan `routes` ke folder proyek Laravel yang baru. Izinkan penggabungan folder. Jika ada file yang sama, jangan asal menimpa: khusus `routes/web.php` dan `database/seeders/DatabaseSeeder.php`, gabungkan kode tugas dengan kode yang sudah ada.

Pastikan file `artisan` berada di akar folder proyek Laravel, sejajar dengan folder `app`, `bootstrap`, `config`, `database`, `public`, `resources`, `routes`, dan `vendor`.

## 3. Siapkan database MySQL
Buat database bernama `db_uts_nim` melalui phpMyAdmin. Atur `.env` di akar proyek Laravel:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=db_uts_nim
DB_USERNAME=root
DB_PASSWORD=
```

Sesuaikan username/password dengan MySQL milikmu.

## 4. Jalankan migration dan seeder
Dari terminal yang sedang berada di akar proyek (folder yang memiliki `artisan`):

```powershell
php artisan optimize:clear
php artisan migrate --seed
php artisan serve
```

Buka `http://127.0.0.1:8000`.

Jika migration tabel `tech_products` sudah pernah dijalankan dan kamu ingin mengulang dari database tugas yang datanya boleh dihapus, gunakan `php artisan migrate:fresh --seed` sebagai pengganti `php artisan migrate --seed`. Perintah `migrate:fresh` menghapus semua tabel di database yang sedang dikonfigurasi, jadi jangan gunakan pada database berisi data penting.

## 5. Gambar
Buat folder `public/assets/images/` dan letakkan gambar dengan nama:
- `laptop.jpg`
- `smartphone.jpg`
- `tablet.jpg`
- `smartwatch.jpg`
- `headphone.jpg`
- `camera.jpg`

Halaman memiliki gambar cadangan jika file gambar belum tersedia, tetapi sesuai soal sebaiknya gambar disimpan di folder tersebut.

## Isi paket
- migration tabel `tech_products`
- model `TechProduct`
- `TechProductSeeder` dengan data dummy
- controller daftar/detail
- route daftar/detail
- layout Blade Bootstrap
- view daftar produk dan detail produk
