
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'TechNova'); ?> | Katalog Teknologi</title>

    <!-- Bootstrap lokal -->
    <link rel="stylesheet" href="<?php echo e(asset('Bootstrap/css/bootstrap.min.css')); ?>">

    <!-- Cadangan agar Bootstrap tetap tampil jika file lokal belum tersedia -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <style>
        body {
            margin: 0;
            background: #f4f7fb;
            color: #172033;
            font-family: Arial, sans-serif;
        }

        .navbar {
            background: #101a30;
            padding: 16px 0;
        }

        .navbar-brand {
            color: white !important;
            font-size: 24px;
            font-weight: 800;
        }

        .navbar .nav-link {
            color: #e2e8f0 !important;
            padding: 10px 14px;
        }

        .navbar .nav-link:hover {
            color: #38bdf8 !important;
        }

        .hero {
            padding: 80px 0;
            color: white;
            background: linear-gradient(120deg, #101a30, #174b8b);
        }

        .hero p {
            color: #dbeafe;
        }

        .section-space {
            padding: 65px 0;
        }

        .product-card {
            height: 100%;
            overflow: hidden;
            border: 0;
            border-radius: 18px;
            transition: .25s;
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 28px #101a3020;
        }

        .product-image {
            width: 100%;
            height: 220px;
            padding: 18px;
            object-fit: contain;
            background: white;
        }

        .price {
            color: #175cd3;
            font-size: 20px;
            font-weight: bold;
        }

        .btn-tech {
            background: #175cd3;
            color: white;
            border: none;
            border-radius: 9px;
            padding: 10px 18px;
            text-decoration: none;
        }

        .btn-tech:hover {
            background: #1247a5;
            color: white;
        }

        #tentang, #kontak, #katalog {
            scroll-margin-top: 80px;
        }

        footer {
            padding: 35px 0;
            color: #cbd5e1;
            background: #101a30;
        }

        footer a {
            color: #e2e8f0;
            text-decoration: none;
        }

        footer a:hover {
            color: #38bdf8;
        }

        @media (max-width: 768px) {
            .hero {
                padding: 55px 0;
            }

            .hero h1 {
                font-size: 34px;
            }

            .section-space {
                padding: 45px 0;
            }
        }
    </style>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('products.index')); ?>">
                TechNova<span class="text-info">.</span>
            </a>

            <button class="navbar-toggler" type="button"
                    data-bs-toggle="collapse"
                    data-bs-target="#mainNavbar"
                    aria-controls="mainNavbar"
                    aria-expanded="false"
                    aria-label="Buka menu">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="mainNavbar">
                <ul class="navbar-nav ms-auto gap-lg-2">
                    <li class="nav-item">
                        <a class="nav-link"
                           href="<?php echo e(route('products.index')); ?>">Beranda</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           href="<?php echo e(route('products.index')); ?>#tentang">Tentang Kami</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           href="<?php echo e(route('products.index')); ?>#katalog">Katalog Produk</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link"
                           href="<?php echo e(route('products.index')); ?>#kontak">Kontak</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <div class="container text-center">
            <h4 class="text-white fw-bold">
                TechNova<span class="text-info">.</span>
            </h4>

            <p>Explore Technology. Discover Possibilities.</p>

            <div class="d-flex justify-content-center flex-wrap gap-3 mb-3">
                <a href="<?php echo e(route('products.index')); ?>">Beranda</a>
                <a href="<?php echo e(route('products.index')); ?>#tentang">Tentang Kami</a>
                <a href="<?php echo e(route('products.index')); ?>#katalog">Katalog Produk</a>
                <a href="<?php echo e(route('products.index')); ?>#kontak">Kontak</a>
            </div>

            <small>&copy; <?php echo e(date('Y')); ?> TechNova.</small>
        </div>
    </footer>

    <script src="<?php echo e(asset('Bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\DIKHI\rekayasa-wab\UTS_251011700459\resources\views/layouts/app.blade.php ENDPATH**/ ?>